-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 27, 2021 at 08:17 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookcart`
--

-- --------------------------------------------------------

--
-- Table structure for table `javascript_books`
--

CREATE TABLE `javascript_books` (
  `img` varchar(1000) NOT NULL,
  `title` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `javascript_books`
--

INSERT INTO `javascript_books` (`img`, `title`) VALUES
('http://books.google.com/books/content?id=9U5I_tskq9MC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Eloquent JavaScript'),
('http://books.google.com/books/content?id=p1v6DwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Eloquent JavaScript'),
('http://books.google.com/books/content?id=ptiYBAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'JavaScript & jQuery: The Missing Manual'),
('http://books.google.com/books/content?id=qU3rAgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Speaking JavaScript'),
('http://books.google.com/books/content?id=PXa2bby0oQ0C&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'JavaScript: The Good Parts'),
('http://books.google.com/books/content?id=IS0EAwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'You Don\'t Know JS: Scope & Closures'),
('http://books.google.com/books/content?id=aAMrswEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'Javascript and Jquery'),
('http://books.google.com/books/content?id=LpctBAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'JavaScript and JQuery'),
('http://books.google.com/books/content?id=XCAREAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Learn JavaScript By Example'),
('http://books.google.com/books/content?id=L46fX62D5qYC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Learning JavaScript Design Patterns'),
('http://books.google.com/books/content?id=nBuA0hmspdMC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Effective JavaScript'),
('http://books.google.com/books/content?id=rkRArW8H_MoC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Testable JavaScript'),
('http://books.google.com/books/content?id=OPbkDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'JavaScript: The Definitive Guide'),
('http://books.google.com/books/content?id=OIhuxqUO2TcC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Functional JavaScript'),
('http://books.google.com/books/content?id=71nDBQAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'JavaScript for Kids'),
('http://books.google.com/books/content?id=jUfnAwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Programming JavaScript Applications'),
('http://books.google.com/books/content?id=GwpVzQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'You Don\'t Know JS Yet'),
('http://books.google.com/books/content?id=oUpYRNKCjrgC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'ppk on JavaScript'),
('http://books.google.com/books/content?id=OgxlDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Rediscovering JavaScript'),
('http://books.google.com/books/content?id=rwiJDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'How JavaScript Works'),
('http://books.google.com/books/content?id=ED6ph4WEIoQC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'High Performance JavaScript'),
('http://books.google.com/books/content?id=FSVTDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Eloquent JavaScript, 3rd Edition'),
('http://books.google.com/books/content?id=Gn1VDgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Refactoring JavaScript'),
('http://books.google.com/books/content?id=XiWGDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Advanced JavaScript'),
('http://books.google.com/books/content?id=2weL0iAfrEMC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'JavaScript: The Definitive Guide'),
('http://books.google.com/books/content?id=r1PODwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'JavaScript for Data Science'),
('http://books.google.com/books/content?id=MrHaC5HAva8C&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'The Book of JavaScript, 2nd Edition'),
('http://books.google.com/books/content?id=cE4BBAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'You Don\'t Know JS: this & Object Prototypes'),
('http://books.google.com/books/content?id=HdCTBQAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'JavaScript Security'),
('http://books.google.com/books/content?id=WTZqecc9olUC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'JavaScript Patterns'),
('http://books.google.com/books/content?id=DprLDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Clean Code in JavaScript'),
('http://books.google.com/books/content?id=zKRY3m6msOIC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Java Script: The Complete Reference'),
('http://books.google.com/books/content?id=4RChxt67lvwC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'JavaScript'),
('http://books.google.com/books/content?id=vlZaDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Learning PHP, MySQL & JavaScript'),
('http://books.google.com/books/content?id=eHq9CgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Start Programming Using HTML, CSS, and JavaScript'),
('http://books.google.com/books/content?id=XXlhHLj6wn8C&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'JavaScript Bible'),
('http://books.google.com/books/content?id=U10PAQAAMAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'Javascript'),
('http://books.google.com/books/content?id=dAYvDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'The Principles of Object-Oriented JavaScript');

-- --------------------------------------------------------

--
-- Table structure for table `php_books`
--

CREATE TABLE `php_books` (
  `img` varchar(1000) NOT NULL,
  `title` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `php_books`
--

INSERT INTO `php_books` (`img`, `title`) VALUES
('http://books.google.com/books/content?id=WSIE9c1olkMC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Delivery of Health Care, California PHP\'s'),
('http://books.google.com/books/content?id=bGS4CmJY0I8C&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Php: The Complete Reference'),
('http://books.google.com/books/content?id=xPe8dPxcU98C&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'AUUG Conference Proceedings'),
('http://books.google.com/books/content?id=pJHuc5c-Qc8C&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Php: A Beginner\'S Gd.'),
('http://books.google.com/books/content?id=noi76uKOJ5wC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'PHP Reference: Beginner to Intermediate PHP5'),
('http://books.google.com/books/content?id=1cmF0twN4rIC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'PHP, MySQL, JavaScript & HTML5 All-in-One For Dummies'),
('http://books.google.com/books/content?id=h-E1lVko-skC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Programming PHP'),
('http://books.google.com/books/content?id=R52auQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'PHP & MySQL'),
('http://books.google.com/books/content?id=HpX4CwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Learning PHP'),
('http://books.google.com/books/content?id=rnSpBgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Modern PHP'),
('http://books.google.com/books/content?id=hHgtAQAAMAAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Proceedings of the Most Excellent Grand Chapter of Royal Arch Masons of Kansas'),
('http://books.google.com/books/content?id=gXTDDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Building Web Apps with WordPress'),
('http://books.google.com/books/content?id=4rs1a6FWx6sC&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'Easy Paypal with Php'),
('http://books.google.com/books/content?id=zMbGvK17_tYC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Extending and Embedding PHP'),
('http://books.google.com/books/content?id=7OjvOmol3CcC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Programming PHP'),
('http://books.google.com/books/content?id=VEix_F-ssrAC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'XML and PHP'),
('http://books.google.com/books/content?id=21MoDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Functional PHP'),
('http://books.google.com/books/content?id=e7D-mITABmEC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Core PHP Programming'),
('http://books.google.com/books/content?id=C0wPAQAAMAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'PHP 6 and MySQL 5 for Dynamic Web Sites'),
('http://books.google.com/books/content?id=Po-1sveqbNkC&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'PHP'),
('http://books.google.com/books/content?id=G4dTRyvpfhoC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'PHP and MySQL Web Development'),
('http://books.google.com/books/content?id=vlZaDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Learning PHP, MySQL & JavaScript'),
('http://books.google.com/books/content?id=lD3S2DmFu0gC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Creating Interactive Websites with PHP and Web Services'),
('http://books.google.com/books/content?id=oJ9QAAAAMAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'PHP 5 Power Programming'),
('http://books.google.com/books/content?id=waBQAAAAMAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'PHP Black Book'),
('http://books.google.com/books/content?id=0kKXzQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'PHP'),
('http://books.google.com/books/content?id=cZ1QAAAAMAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'PHP 4 Bible'),
('http://books.google.com/books/content?id=U8pQAAAAMAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'PHP 5 Objects, Patterns, and Practice'),
('http://books.google.com/books/content?id=3tkFaL_IQZ0C&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'MySQL/PHP Database Applications'),
('http://books.google.com/books/content?id=UJ5QAAAAMAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'Essential PHP for Web Professionals'),
('http://books.google.com/books/content?id=gupSAAAAMAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'Apache, MySQL, and PHP Weekend Crash Course'),
('http://books.google.com/books/content?id=UacqAAAAMAAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Proceedings of the Grand Chapter of Royal Arch Masons of the State of California at Its ... Annual Convocation'),
('http://books.google.com/books/content?id=mgt_We3tw-0C&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Learning PHP, MySQL, JavaScript, and CSS'),
('http://books.google.com/books/content?id=IpuT0GxHvAkC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Learning PHP & MySQL'),
('http://books.google.com/books/content?id=qSAiAQAAIAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'PHP Programming with MySQL'),
('http://books.google.com/books/content?id=FrbjCwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Learning PHP 7'),
('http://books.google.com/books/content?id=iUfIqyAbIU4C&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'PHP Cookbook'),
('http://books.google.com/books/content?id=ke9SAAAAMAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'Build Your Own Database Driven Website Using PHP & MySQL');

-- --------------------------------------------------------

--
-- Table structure for table `python_books`
--

CREATE TABLE `python_books` (
  `img` varchar(1000) NOT NULL,
  `title` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `python_books`
--

INSERT INTO `python_books` (`img`, `title`) VALUES
('http://books.google.com/books/content?id=4pgQfXQvekcC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Learning Python'),
('http://books.google.com/books/content?id=zjqzDAEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'Python for Everybody'),
('http://books.google.com/books/content?id=6omNDQAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Python Data Science Handbook'),
('http://books.google.com/books/content?id=BcN0swEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'Python Tricks'),
('http://books.google.com/books/content?id=8AcvDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Automate the Boring Stuff with Python'),
('http://books.google.com/books/content?id=fD8CngEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'Python for Informatics'),
('http://books.google.com/books/content?id=UWlo-c4WEpAC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Python for Data Analysis'),
('http://books.google.com/books/content?id=wGLPDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Let Us Python (Second Edition)'),
('http://books.google.com/books/content?id=b1v6DwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Serious Python'),
('http://books.google.com/books/content?id=7IUBEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Real-World Python'),
('http://books.google.com/books/content?id=b-2oDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Python Programming in Context'),
('http://books.google.com/books/content?id=nOPuDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Introduction to Scientific Programming with Python'),
('http://books.google.com/books/content?id=kKjgDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'High Performance Python'),
('http://books.google.com/books/content?id=pMEUG8oNBfkC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Python for Kids'),
('http://books.google.com/books/content?id=M68hAwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Python for Software Design'),
('http://books.google.com/books/content?id=6xIwDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Python for Bioinformatics'),
('http://books.google.com/books/content?id=89W8DwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Introducing Python'),
('http://books.google.com/books/content?id=KabKDAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Introduction to Computation and Programming Using Python'),
('http://books.google.com/books/content?id=KGIbfiiP1i4C&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Natural Language Processing with Python'),
('http://books.google.com/books/content?id=R9vQAQAACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'The Quick Python Book'),
('http://books.google.com/books/content?id=ZPneDQAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Invent Your Own Computer Games with Python, 4th Edition'),
('http://books.google.com/books/content?id=iIqADwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Introduction to Python Programming'),
('http://books.google.com/books/content?id=qX0dwQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'THE GUN RIGHTS WAR'),
('http://books.google.com/books/content?id=Yo3CAQAACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'Deep Learning with Python'),
('http://books.google.com/books/content?id=w84wDgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Introduction to Data Science'),
('http://books.google.com/books/content?id=_ERADwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Begin to Code with Python'),
('http://books.google.com/books/content?id=4yXtDAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'The Hitchhiker\'s Guide to Python'),
('http://books.google.com/books/content?id=7z_fCQAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Web Scraping with Python'),
('http://books.google.com/books/content?id=zZrexQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'LEARNING WITH PYTHON.'),
('http://books.google.com/books/content?id=NIqNDQAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Head First Python'),
('http://books.google.com/books/content?id=iJ_AAgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Image Processing and Acquisition using Python'),
('http://books.google.com/books/content?id=6ifuzQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'Python for Data Science: The Ultimate Beginner\'s Guide to Learn Data Science, Analysis, and Machine Learning from Scratch with Step-by-Step Exe'),
('http://books.google.com/books/content?id=_UT1ZwEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'Problem Solving with Algorithms and Data Structures Using Python'),
('http://books.google.com/books/content?id=M97fDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Python for MBAs'),
('http://books.google.com/books/content?id=l6O-DwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Python Projects for Beginners'),
('http://books.google.com/books/content?id=J9b_CH-NrycC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Programming Computer Vision with Python'),
('http://books.google.com/books/content?id=bIZHCgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Fluent Python'),
('http://books.google.com/books/content?id=eR-vCgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Introduction to Computational Models with Python'),
('http://books.google.com/books/content?id=GOVOCwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Python Machine Learning'),
('http://books.google.com/books/content?id=WkUnCgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Beginning Python');

-- --------------------------------------------------------

--
-- Table structure for table `recomend_books`
--

CREATE TABLE `recomend_books` (
  `img` varchar(1000) NOT NULL,
  `title` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recomend_books`
--

INSERT INTO `recomend_books` (`img`, `title`) VALUES
('http://books.google.com/books/content?id=UAYvDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Eloquent JavaScript'),
('http://books.google.com/books/content?id=aGjaBTbT0o0C&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'HTML and CSS'),
('http://books.google.com/books/content?id=4pgQfXQvekcC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Learning Python'),
('http://books.google.com/books/content?id=jBm3DwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Interpretable Machine Learning'),
('http://books.google.com/books/content?id=ZDBbG41-BA8C&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'The Book of Ruby'),
('http://books.google.com/books/content?id=XXdyQgAACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'The C Book, Featuring the ANSI C Standard'),
('http://books.google.com/books/content?id=HcqPDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Laravel: Up & Running'),
('http://books.google.com/books/content?id=ppjUtAEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api', 'Fullstack React'),
('http://books.google.com/books/content?id=y4AZ-k-zUskC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Note on Angular Distributions in Nuclear Reactions'),
('http://books.google.com/books/content?id=epaCypdPNOcC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 'Professional CodeIgniter');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `mode` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `email`, `pass`, `mode`) VALUES
('Argha Paul', 'arghapaul100@gmail.com', '12345', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
