<?php

class About extends CI_Controller{
	
}


?>